#include "insert_doc.h"

insert_doc::insert_doc(QWidget *parent)
    : QWidget{parent}
{

}
