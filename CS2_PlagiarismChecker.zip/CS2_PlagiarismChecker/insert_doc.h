#ifndef INSERT_DOC_H
#define INSERT_DOC_H

#include <QWidget>

class insert_doc : public QWidget
{
    Q_OBJECT
public:
    explicit insert_doc(QWidget *parent = nullptr);

signals:

};

#endif // INSERT_DOC_H
